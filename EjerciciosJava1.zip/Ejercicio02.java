public class Ejercicio02 {
   public static void main(String[] args) {
    int myNum1 = 7;
    int myNum2 = 5;
    boolean esMayor = myNum1 > myNum2; 
    boolean esMenorOIgual = myNum1 <= myNum2; 
    System.out.println("Es " + myNum1 + " mayor que " + myNum2 + " : " + esMayor);
    System.out.println("Es " + myNum1 +  " menor o igual que " + myNum2 + " : " + esMenorOIgual);
   }
}
