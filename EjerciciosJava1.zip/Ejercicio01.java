public class Ejercicio01 {
    public static void main(String[] args) {
     int myNum1 = 5;
     int myNum2 = 5;
     int suma = myNum1 + myNum2;
     System.out.println("Suma: " + suma);
     int resta = myNum1 - myNum2;
     System.out.println("Resta: " + resta);
     int multiplicacion = myNum1 * myNum2;
     System.out.println("Multiplicacion: " + multiplicacion);
     int division = myNum1 / myNum2;
     System.out.println("Division: " + division);
     int modulo = myNum1 % myNum2;
     System.out.println("Modulo: " + modulo);
    }
    
}
