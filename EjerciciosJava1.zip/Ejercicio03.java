public class Ejercicio03 {
    public static void main(String[] args) {
        String nombre = "Sol";
        System.out.println("Bienvenido/a " + nombre);
    }
}
